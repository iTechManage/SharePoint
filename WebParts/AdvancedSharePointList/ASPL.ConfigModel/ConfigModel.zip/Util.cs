﻿using System.Xml;
using System.Xml.Linq;
using System;

namespace ASPL.ConfigModel
{
    public class Util
    {
        public static bool IsValidXml(string xml)
        {
            XmlDocument xDoc = new XmlDocument();

            try
            {
                xDoc.LoadXml(xml);
                return true;
            }
            catch (Exception)
            {
                return false; 
            }
        }

        public static XmlDocument LoadXml(string path)
        {
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(path);
            return xDoc;
        }

        public static bool ConvertToBool(string value)
        {
            bool result = false;
            Boolean.TryParse(value, out result);
            return result;
        }

       
    }
}
