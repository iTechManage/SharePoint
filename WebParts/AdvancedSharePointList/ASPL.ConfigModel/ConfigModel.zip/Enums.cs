﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPL.ConfigModel
{
    public class Enums
    {
        public enum PermissionLevel{Read=11,Write=12,Deny=13};
        [Flags]
        public enum SPForms { New=21,Edit=22,View=23}
        public enum ValidationRule {Pattern=31,length=32,Column=33, Invalid=30};
        public enum Operator { In=101, NotIn=102, Equal=103, NotEqual=104, Contains=105, NotContains=106, GreaterThen=107, LessThen=108, None=100 };

    }


}
