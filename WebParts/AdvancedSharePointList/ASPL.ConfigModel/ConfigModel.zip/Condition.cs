﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace ASPL.ConfigModel
{
    public class Condition
    {
        internal Condition() { }

        public Condition(Field onField, Enums.Operator byFieldOperator,object value)
        {
            this.OnField = onField;
            this.ByFieldOperator = byFieldOperator;
            this.Value = value;
        }

        public Field OnField { get; set; }
        public Enums.Operator ByFieldOperator { get; set; }
        public object Value { get; set; }

        public override string ToString()
        {
            return string.Format("<condition>{0};{1};{2}</condition>", this.OnField.SPName, this.ByFieldOperator.ToString(), this.Value.ToString());
        }
    }

    public class Conditions : List<Condition>
    {
        public static Conditions LoadConditions(XmlNode node)
        {
            Conditions conditions = new Conditions();
            foreach (XmlNode childNode in node.ChildNodes)
            {
                if (childNode.Name.Equals("conditions", StringComparison.InvariantCultureIgnoreCase) && !string.IsNullOrEmpty(childNode.InnerText))
                {
                    Condition c = new Condition()
                    {
                        OnField = new Field(childNode.InnerText.Split(';')[0]),
                        ByFieldOperator = (Enums.Operator)Enum.Parse(typeof(Enums.Operator), childNode.InnerText.Split(';')[1], true),
                        Value = childNode.InnerText.Split(';')[2]
                    };
                    conditions.Add(c);               
                }
            }

            return conditions;
        }
        public override string ToString()
        {
            string str = string.Empty;
            foreach (Condition item in this)
            {
                str += item.ToString();
            }
            return string.Format("<conditions>{0}</conditions>", str);
        }
    }
}
