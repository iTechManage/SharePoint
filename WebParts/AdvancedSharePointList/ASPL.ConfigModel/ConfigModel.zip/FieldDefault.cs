﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace ASPL.ConfigModel
{
    public class FieldDefault
    {
        public Field OnField { get; set; }
        public string ForSPPrinciples { get; set; }
        public Enums.Operator BySPPrinciplesOperator { get; set; }
        public string SPContentType { get; set; }
        public object Value { get; set; }

        internal FieldDefault(XmlNode fieldDefaultNode)
        {
            string defaultSetting = fieldDefaultNode.InnerText;
            this.OnField = new Field(defaultSetting.Split(';')[0]);
            this.Value = defaultSetting.Split(';')[1];
            this.ForSPPrinciples = defaultSetting.Split(';')[2];
            this.BySPPrinciplesOperator = (Enums.Operator)Enum.Parse(typeof(Enums.Operator), defaultSetting.Split(';')[3], true);
            this.SPContentType = defaultSetting.Split(';')[4];
            
        }

        public FieldDefault(Field onField, string forSPPrinciples, Enums.Operator bySPPrinciplesOperator, string spContentType, object value)
        {
            this.OnField = onField;
            this.ForSPPrinciples =forSPPrinciples;
            this.BySPPrinciplesOperator = bySPPrinciplesOperator;
            this.SPContentType = spContentType;
            this.Value = value;
        }
        
        public override string ToString()
        {
            return string.Format("<default>{0};{1};{2};{3};{4}</default>",
                            this.OnField.SPName,Value.ToString(),this.ForSPPrinciples,this.BySPPrinciplesOperator,this.SPContentType);
        }
    }

    public class FieldDefaults:List<FieldDefault>
    {

        public static FieldDefaults LoadFieldDefaults(XmlDocument xmlFieldDefaults)
        {
            if(xmlFieldDefaults == null) return null;

            FieldDefaults fieldDefaults = new FieldDefaults();

            XmlNodeList xmlFieldValidationNodes = xmlFieldDefaults.SelectNodes("/fielddefaults/default");

            foreach (XmlNode node in xmlFieldValidationNodes)
            {
                FieldDefault f = new FieldDefault(node);
                fieldDefaults.Add(f);
            }
            return fieldDefaults;
        }
        public override string ToString()
        {
            string str = string.Empty;
            foreach (FieldDefault item in this)
            {
                str += item.ToString();
            }
            return string.Format("<fielddefaults>{0}</fielddefaults>",str);
        }
    }
}
